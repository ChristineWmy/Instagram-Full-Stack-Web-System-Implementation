import flask
app = flask.Flask(__name__)

# app.secret_key = b'SEE NEXT SLIDE TO CREATE YOUR OWN'


@app.route('/')
def index():
    return 'index page'
    # if 'username' in flask.session:
    #     user = flask.session['username']
    #     return 'Logged in as {}\n <a href="/logout/">Logout</a>'.format(user)
    # return 'You are not logged in\n'


@app.route('/login/', methods=['GET', 'POST'])
def login():
    if flask.request.method == 'POST':
        print("DEBUG", flask.request.form['username'])
        # flask.session['username'] = flask.request.form['username']
        return flask.redirect(flask.url_for('index'))
    return '''
    <form action="" method="post">
      <p><input type=text name=username>
      <p><input type=submit value=Login>
    </form>'''


@app.route('/logout/')
def logout():
    flask.session.clear()
    return flask.redirect(flask.url_for('index'))


if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=8000)
